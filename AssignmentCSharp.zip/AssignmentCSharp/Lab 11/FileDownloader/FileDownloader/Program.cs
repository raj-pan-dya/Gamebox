﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDownloader
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Instantiate
            FileDownloader fd = new FileDownloader("http://www.microsoft.com/vstudio/expressv10.zip", @"C:\Users\ampotdar\Downloads");
            //Register Event Handler
            fd.DownLoadComplete += new DownloadCompeteHandler(Fd_DownLoadComplete);
            //Start the task...
            fd.DownLoadResource(); // OndownloadComplete() -> Event "DownloadComplete()" (this event contains reference of Fd_DownloadComplete()
            //fd.DownLoadComplete(5);
            Console.ReadKey();
        }

        //Function to be called when event raises
        static void Fd_DownLoadComplete(int perc)
        {
            Console.SetCursorPosition(10, 10);
            Console.Write("Downloading {0} Percent Complete", perc);
        }
    }
}
