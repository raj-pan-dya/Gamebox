﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace _8._1
{
    class Program
    {     
        static void Main(string[] args)
        {
            string distCode, district;
            Console.WriteLine("==========RTO Records Application==========");

            char flag;
            do
            {
                int option;
                Console.WriteLine("PLease select an option:\n(1)Add record\n" +
                                                            "(2)Search record\n" +
                                                            "(3)Display all records\n" +
                                                            "(4)Total count\n" +
                                                            "(5)Remove record\n");
                option = Convert.ToInt32(Console.ReadLine());
                Hashtable htRecord = new Hashtable();

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Please enter the details to be added\n" +
                                          "RTO district code: ");
                        distCode = Console.ReadLine();

                        Console.WriteLine("RTO district: ");
                        district = Console.ReadLine();

                        AddRecord(distCode, district);
                                                
                        Console.WriteLine("Record added successfully!");
                        break;

                    case 2:
                        Console.WriteLine("Please enter the district code to search record\n" +
                                          "District Code: ");
                        distCode = Console.ReadLine();
                        SearchRecord(distCode);
                        break;

                    case 3:
                        DisplayRecords();
                        break;

                    case 4:
                        Count();
                        break;

                    case 5:
                        Console.WriteLine("Please enter the district code of the record to be removed\n" +
                                          "District code: ");
                        distCode = Console.ReadLine();
                        RemoveRecord(distCode);
                        break;

                    default:
                        Console.WriteLine("Please select from given options!");
                        break;
                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue 'n' to exit");
                flag = Convert.ToChar(Console.ReadLine());

            } while (flag == 'y' || flag =='Y');


        }

        public static Hashtable htRecord = new Hashtable();

        public static Hashtable AddRecord(string distCode, string district)
        {            
            htRecord.Add(distCode, district);

            return htRecord;
        }

        public static Hashtable SearchRecord(string distCode)
        {
            bool condition = htRecord.ContainsKey(distCode);
            string str = (string)htRecord[distCode];
            if (condition)
            {
                Console.WriteLine(distCode + " " + str);
            }
            return htRecord;
        }

        public static Hashtable DisplayRecords()
        {
            foreach (DictionaryEntry record in htRecord)
            {
                Console.WriteLine("{0},{1}", record.Key, record.Value);
            }

            return htRecord;
        }

        public static Hashtable Count()
        {
            Console.WriteLine("Count: " + htRecord.Count);
            return htRecord;
        }

        public static Hashtable RemoveRecord(string distCode)
        {
            htRecord.Remove(distCode);
            Console.WriteLine("Record removed successfully");
            return htRecord;
        }
        


    }
}
