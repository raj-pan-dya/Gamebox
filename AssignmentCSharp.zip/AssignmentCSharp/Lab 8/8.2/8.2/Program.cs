﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace _8._2
{
    class Program
    {
        static void Main(string[] args)
        {
            GetHashtable();
            //Task 1
            bool searchKey, search;
            searchKey = hashtable.ContainsKey("Perimeter");
            search = hashtable.Contains("Perimeter");
            Console.WriteLine("Search results using ContainsKey Method: " + searchKey);
            Console.WriteLine("Search results using Contains Method: " + search);
            //There is no difference in the results.

            //Task 2           
            Console.WriteLine("Value of Area is " + (int)hashtable["Area"]);

            //Task 3
            hashtable.Remove("Mortgage");
            Console.WriteLine("Record with key Mortgage was removed");
        }

        static Hashtable hashtable = new Hashtable();

        static Hashtable GetHashtable()
        {            
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;           
        }
       
    }
}
