﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_lib
{
    class PermanentEmployee : Employee
    {
        private int salary, employeeId;
        private string employeeName, address, city, department;
        int noOfLeaves;
        int providendFund;
        public int NoOfLeaves
        {
            get
            {
                return noOfLeaves;

            }
            set
            {

                noOfLeaves = value;

            }
        }
        
        public int ProvidendFund
        {
            get
            {
                return providendFund;

            }
            set
            {

                providendFund = value;

            }
        }
        override public int GetSalary(string employeeName, string address, string city, string department, int salary, int employeeId)
        {

            Console.WriteLine("Please enter the Providend fund of Permanent Employee");
            providendFund = Convert.ToInt32(Console.ReadLine());
            EmployeeName = employeeName;
            Address = address;
            City = city;
            Department = department;
            Salary = salary;
            EmployeeId = employeeId;
           
            return (Salary - providendFund);

        }

    }
}
