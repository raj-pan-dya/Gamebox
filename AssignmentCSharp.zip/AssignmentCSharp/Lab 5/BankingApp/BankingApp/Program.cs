﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLib;

namespace BankingApp
{
    class Program
    {

        static void Main(string[] args)
        {
            ICICI objIC1 = new ICICI();
            BankAccountTypeEnum value = BankAccountTypeEnum.Saving;
            objIC1.Deposit(50000, value);
            Console.Write("Balance in " + value +" Account of ICICI in IC1 after Deposit: ");
            Console.WriteLine(objIC1.GetBalance());

            ICICI objIC2 = new ICICI();
            value = BankAccountTypeEnum.Current;
            objIC2.Deposit(20000, value);
            Console.Write("Balance in " + value + " Account of ICICI in IC2 after Deposit: ");
            Console.WriteLine(objIC2.GetBalance());

            objIC1.Transfer(objIC2, 5000);
            Console.Write("Balance in ICICI in IC1 after Transfer: ");
            Console.WriteLine(objIC1.GetBalance());
            Console.Write("Balance in ICICI in IC2 after Transfer: ");
            Console.WriteLine(objIC2.GetBalance());




            HSBC objH1 = new HSBC();
            value = BankAccountTypeEnum.Saving;
            objH1.Deposit(50000, value);
            Console.Write("Balance in " + value + " Account of HSBC in H1 after Deposit: ");
            Console.WriteLine(objH1.GetBalance());

            HSBC objH2 = new HSBC();
            value = BankAccountTypeEnum.Current;
            objH2.Deposit(20000, value);
            Console.Write("Balance in " + value + " Account of HSBC in H1 after Deposit: ");
            Console.WriteLine(objH2.GetBalance());

            objH1.Transfer(objH2, 5000);
            Console.Write("Balance in HSBC in H1 after Transfer: ");
            Console.WriteLine(objH1.GetBalance());
            Console.Write("Balance in HSBC in H1 after Transfer: ");
            Console.WriteLine(objH2.GetBalance());


            // Task to be performed:
            //             Create a Object of ICICI
            //            Set the Account type to Saving(Use enum)
            //            Deposit Rs. 50000 to this account
            //            Create another Object of ICICI
            //            Set the Account type to Current (use enum)
            //            Deposit Rs. 20000 to this account
            //              Print the Balance of both these account objects.
            //              Now call the Transfer function to transfer the money from Savings account to Current Account.
            //              The amount to be transferred is Rs. 5000.
            //          e.g.a1.Transfer(a2,5000);
            //          Now print the Balance after the Transfer from both the accounts.
            //          Similarly, create two accounts of HSBC Bank.Transfer Rs. 30000 from Saving to Current and display the
            //          balance.


        }
    }
}
