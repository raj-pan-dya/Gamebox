﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimArray
{
    class Program
    {
        static void Main(string[] args)
        {
            SingleDArray();
        }
        static void SingleDArray()
        {
            Console.WriteLine("Enter some names of Cities(5): ");
            Console.WriteLine();
            string[] strCities = new string[5];
            for (int i = 0; i < strCities.Length; i++)
            {
                strCities[i] = Console.ReadLine();
            }

            //
            Console.WriteLine("List of Cities: ");
            foreach (string strCity in strCities)
            {
                Console.WriteLine(strCity);
            }
        }
    }
}
