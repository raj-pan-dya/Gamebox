﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDetails
{
    public class BookDemo
    {
        public string[] colName = new string[4] { "Book Title", "Author", "Publisher", "Price" };
        public string[,] bookDetails = new string[2, 4];
    }
}
