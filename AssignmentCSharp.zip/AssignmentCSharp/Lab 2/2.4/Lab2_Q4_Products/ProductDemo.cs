﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Q4_Products
{
    class ProductDemo
    {
        public void productDetails()
        {


            int productId;
            string productName;
            int price;
            int quantity;
            double amount;

            //Boxing... Converting Value type to Reference type
            Console.Write("Please enter the Product ID :");
            productId = Convert.ToInt32(Console.ReadLine());
            object oproductId = productId;

            Console.Write("Please enter the Product Name :");
            productName = Console.ReadLine();
            object oproductName = productName;

            Console.Write("Please enter the Product Price :");
            price = Convert.ToInt32(Console.ReadLine());
            object oprice = price;

            Console.Write("Please enter the Product Quantity :");
            quantity = Convert.ToInt32(Console.ReadLine());
            object oquantity = quantity;

            //Unboxing... Extracting the value type from the object
            Console.WriteLine("\n PRODUCT DETAILS :");
            productId = (int)oproductId;
            Console.WriteLine("\n Product ID is :" +productId);

            productName = (string)oproductName;
            Console.WriteLine("\n Product Name is :" +productName);

            price = (int)oprice;
            Console.WriteLine("\n Product Price is :" +price);

            quantity = (int)oquantity;
            Console.WriteLine("\n Quantity of the Product is :" +quantity);

            amount = price * quantity;
            Console.WriteLine("\n The total Payable Amount is : " +amount);
        }
    }
}
