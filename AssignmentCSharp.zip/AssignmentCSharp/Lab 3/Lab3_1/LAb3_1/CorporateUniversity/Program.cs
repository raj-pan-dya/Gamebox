﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParticipantLib;

namespace CorporateUniversity
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---------------Corporate University----------------");
            Console.WriteLine("Enter the details of the participant");
            Participant objP = new Participant();
            Console.Write("Employee ID: ");
            objP.empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Employee Name: ");
            objP.name = Console.ReadLine();
            Console.Write("Foundation Marks: ");
            objP.foundationMarks = Convert.ToInt32(Console.ReadLine());
            Console.Write("Web Basics Marks: ");
            objP.webBasicsMarks = Convert.ToInt32(Console.ReadLine());
            Console.Write("Dot Net Marks: ");
            objP.dotNetMarks = Convert.ToInt32(Console.ReadLine());

            
            
            objP.CalculateTotalMarks();
            objP.CalculatePercentage();
            Console.WriteLine("Percentage of the Employee "+objP.name+ " is " + objP.ReturnPercentage() + "%");
        }
    }
}
