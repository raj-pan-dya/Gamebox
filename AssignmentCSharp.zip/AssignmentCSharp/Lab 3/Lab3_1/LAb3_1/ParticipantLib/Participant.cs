﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParticipantLib
{
    public class Participant
    {
        int _empId;
        string _name;
        static string _companyName;
        double _foundationMarks;
        double _webBasicsMarks;
        double _dotNetMarks;
        double _totalMarks = 300.00;
        double _obtainedMarks;
        double _percentage;

        public int empId
        {
            get
            {
                return _empId;
            }
            set
            {
                _empId = value;
            }
        }
        public string name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public static string companyName
        {
            get
            {
                return Participant._companyName;
            }
            set
            {
                Participant._companyName = value;
            }
        }
        public double foundationMarks
        {
            get
            {
                return _foundationMarks;
            }
            set
            {
                if (value < 100 && value > 0)
                {
                    _foundationMarks = value;
                }
                else
                {
                    _foundationMarks = 0;
                }
               
            }
        }
        public double webBasicsMarks
        {
            get
            {
                return _webBasicsMarks;
            }
            set
            {
                if (value < 100 && value > 0)
                {
                    _webBasicsMarks = value;
                }
                else
                {
                    _webBasicsMarks = 0;
                }
                
            }
        }
        public double dotNetMarks
        {
            get
            {
                return _dotNetMarks;
            }
            set
            {
                if (value < 100 && value > 0)
                {
                    _dotNetMarks = value;
                }
                else
                {
                    _dotNetMarks = 0;
                }
                
            }
        }
        public double totalMarks
        {
            get
            {
                return _totalMarks;
            }
            set
            {
                _totalMarks = value;
            }
        }
        public double obtainedMarks
        {
            get
            {
                return _obtainedMarks;
            }
            set
            {
                _obtainedMarks = value;
            }
        }
        public double percentage
        {
            get
            {
                return _percentage;
            }
            set
            {
                _percentage = value;
            }
        }


        public Participant()
        {

        }

        public Participant(int empId, string name, int foundationMarks, int webBasicsMarks, int dotNetMarks)
        {
            this.empId = empId;
            this.name = name;
            this.foundationMarks = foundationMarks;
            this.webBasicsMarks = webBasicsMarks;
            this.dotNetMarks = dotNetMarks;
        }

        static Participant() {
            companyName = "Corporate University";
        }

        public void CalculateTotalMarks()
        {
            obtainedMarks = foundationMarks + webBasicsMarks + dotNetMarks;
        }

        public void CalculatePercentage()
        {
            percentage = (obtainedMarks / totalMarks) * 100;
        }

        public double ReturnPercentage()
        {
            return percentage;
        }

    }

}
