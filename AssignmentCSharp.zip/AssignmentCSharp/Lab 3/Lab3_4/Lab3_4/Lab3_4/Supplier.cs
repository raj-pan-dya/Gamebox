﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class Supplier
    {
        int supplierId;
        string supplierName, city, phonenum, email;

        public void setDetails(int supplierId,string supplierName,string city,string phonenum, string email)
        {
            this.supplierId = supplierId;
            this.supplierName = supplierName;
            this.city = city;
            this.phonenum = phonenum;
            this.email = email;
        }

        public void displayDetails()
        {
            Console.WriteLine(supplierId + supplierName + city + phonenum + email);
        }
    }
}
