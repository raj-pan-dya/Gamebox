﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Delegates
{
    
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Arithmetic Operations using delegates");
            Console.WriteLine("Enter first No.");

            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second No.");

            num2 = Convert.ToInt32(Console.ReadLine());
            ArithmeticOperation arthOp = new ArithmeticOperation();
            newDelegate del = new newDelegate(arthOp.Add);

            double resultAdd = ArithmeticOperation.PerformArithmeticOperation(num1, num2, del);
             del = new newDelegate(arthOp.Subtract);
            double resultSub = ArithmeticOperation.PerformArithmeticOperation(num1, num2, del);
            del = new newDelegate(arthOp.Multiply);
            double resultMul = ArithmeticOperation.PerformArithmeticOperation(num1, num2, del);
            del = new newDelegate(arthOp.Divide);
            double resultDiv = ArithmeticOperation.PerformArithmeticOperation(num1, num2, del);
            del = new newDelegate(arthOp.Max);
            double resultMax = ArithmeticOperation.PerformArithmeticOperation(num1, num2, del);

            Console.WriteLine("Addition \t: {0}\nSubstraction\t: {1}\nMultiplication\t: {2}\nDivision\t: {3}\nMax of Two\t: {4}", resultAdd,resultSub, resultMul, resultDiv,resultMax);

           

        }
    }
}
