﻿/*********************************************************************
 * File                 : GuestPhoneBookException.cs
 * Author Name          : Sayali Chincholikar
 * Desc                 : Program to design Console Application and display the required output.
 * Version              : 1.0
 * Last Modified Date   : 01-Dec-2018
 * Change Description   : Description about the changes implemented
 ********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBook.Exceptions
{
    public class GuestPhoneBookException:ApplicationException
    {
        public GuestPhoneBookException()
            : base()
        {
        }

        public GuestPhoneBookException(string message)
            : base(message)
        {
        }
        public GuestPhoneBookException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
