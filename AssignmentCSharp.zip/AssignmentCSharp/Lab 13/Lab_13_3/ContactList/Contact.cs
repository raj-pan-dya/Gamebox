﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{

    [Serializable]
    public class Contact
    {
        

        private int _contactNo;
        private string _contactName;
        private string _cellNo;

        public int ContactNo
        {
            get
            {
                return _contactNo;
            }
            set
            {
                _contactNo = value;
            }
        }

        public string ContactName
        {
            get
            {
                return _contactName;
            }
            set
            {
                _contactName = value;
            }
        }

        public string CellNo
        {
            get
            {
                return _cellNo;
            }
            set
            {
                _cellNo = value;
            }
        }


    }
}
