﻿//<Summary>
/*********************************************************************
 * File                 : ContactOps.cs
 * Author Name          : Sayali Chincholikar
 * Desc                 : Accept the data for multiple contacts. Serialize the List using SOAP.
 * Version              : 1.0
 * Last Modified Date   : 01-Dec-2018
 * Change Description   : Description about the changes implemented
 ********************************************************************/
//</Summary>
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace ContactList
{
   
    class ContactOps
    {
        
       
        public static ArrayList listObj = new ArrayList();
      
        public static ArrayList listObj1 = new ArrayList();

        

        public static void AddContact()
        {
            Contact conObj = new Contact();
                  
            Console.WriteLine("Enter Contact Details:");

            Console.WriteLine("Enter ContactNo: ");
            conObj.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter ContactName: ");
            conObj.ContactName = Console.ReadLine();

            Console.WriteLine("Enter CellNo: ");
            conObj.CellNo = Console.ReadLine();

            listObj.Add(conObj);
            
           
        }
    



        public static void ShowAllContacts(ArrayList listObj )
        {
            Console.WriteLine("List of Contact Details:");
            foreach(Contact objContact in listObj)
            {
               
                Console.WriteLine("ContactNo: {0} Contact Name: {1} Cell No: {2}" , objContact.ContactNo ,objContact.ContactName ,objContact.CellNo);


            }
        }

        //Lab 13_3
        //Serializing Contact list using SOAP Formatter 
        public static void SerializeListSOAP()
        {
            FileStream stream = new FileStream(@"C:\Users\schincho\Documents\AssignmentCSharp\Lab 13\Lab_13_1 & Lab_13_2\ContactListSOAP.xml", FileMode.Create);
           SoapFormatter soap = new SoapFormatter();
            object obj = listObj;
            soap.Serialize(stream, obj);
            stream.Close();
        }

        //Lab 13_3
        //DeSerializing Contact list using SOAP Formatter 
        public static ArrayList DeSerializeListSOAP()
        {
            FileStream stream = new FileStream(@"C:\Users\schincho\Documents\AssignmentCSharp\Lab 13\Lab_13_1 & Lab_13_2\ContactListSOAP.xml", FileMode.Open);
            SoapFormatter soap = new SoapFormatter();

            listObj1 = soap.Deserialize(stream) as ArrayList;
            stream.Close();
            return listObj1;

        }

    }
}
