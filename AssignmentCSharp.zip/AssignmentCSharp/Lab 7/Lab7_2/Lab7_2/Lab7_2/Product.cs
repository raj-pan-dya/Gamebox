﻿/*********************************************************************
 * File                 : Product.cs
 * Author Name          : Sayali Chincholikar
 * Desc                 : Program to create a console application to 
                          accept Product details like ProductNo, Name, 
                          Rate and Stock.
 * Version              : 1.0
 * Last Modified Date   : 29-Nov-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_2
{
    public class Product
    {
        public int ProductNo { get; set; }
        public string ProductName { get; set; }
        public int Rate { get; set; }
        public int Stock { get; set; }
    }
}
