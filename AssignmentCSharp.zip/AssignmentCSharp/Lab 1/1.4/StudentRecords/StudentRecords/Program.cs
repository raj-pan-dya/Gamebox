﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecords
{
    class Program
    {
        static void Main(string[] args)
        {
            char flag;
            Console.WriteLine("--------------- Student Record App -------------");
            Console.WriteLine();
            Console.WriteLine("Enter the details of the student");
            Records objRecord = new Records();
            do {
                Console.WriteLine();
                Console.Write("Roll Number: ");
                objRecord.rollNumber = Convert.ToInt32(Console.ReadLine());
                Console.Write("Student Name: ");
                objRecord.studentName = Console.ReadLine();
                Console.Write("Age: ");
                objRecord.age = Convert.ToByte(Console.ReadLine());
                Console.Write("Gender: ");
                objRecord.gender = Convert.ToChar(Console.ReadLine());
                Console.Write("Date of Birth: ");
                objRecord.dateOfBirth = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Address: ");
                objRecord.address = Console.ReadLine();
                Console.Write("Percentage: ");
                objRecord.percentage = float.Parse(Console.ReadLine());
                Console.WriteLine();
                
                Console.WriteLine("Roll Number: " + objRecord.rollNumber + ", Student Name: " + objRecord.studentName + ", Age: " + objRecord.age + ", Gender: " + objRecord.gender + ", D.O.B: " + objRecord.dateOfBirth + ", Address: " + objRecord.address + ", Percentage: " + objRecord.percentage +"%");
                Console.WriteLine();
                Console.WriteLine("Do you want to continue? Press 'y' to continue 'n' to exit");
                flag = Convert.ToChar(Console.ReadLine());

            } while (flag == 'y');

        }
    }
}
