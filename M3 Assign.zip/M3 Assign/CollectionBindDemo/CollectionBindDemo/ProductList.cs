﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace CollectionBindDemo
{

    public class ProductList: ObservableCollection<Product>
    {
        public ProductList()
        {
            Product p = new Product();
            p.ProductName = "Black Berry"; p.ProductStock = 100;
            this.Add(p);
            p = new Product();
            p.ProductName = "Samsung Galaxy"; p.ProductStock = 200;
            this.Add(p);
            p = new Product();
            p.ProductName = "Samsung Wave"; p.ProductStock = 300;
            this.Add(p);
        }
    }
}
