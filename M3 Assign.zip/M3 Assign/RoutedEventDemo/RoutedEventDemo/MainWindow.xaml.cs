﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoutedEventDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btneventtest_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Add("Button " + e.RoutedEvent.Name);
        }

        private void Window_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Clear();
            listBox1.Items.Add("Window " + e.RoutedEvent.Name);
        }

        private void Window_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Add("Window " + e.RoutedEvent.Name);
        }

        private void Grid_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Add("Grid " + e.RoutedEvent.Name);
        }

        private void Grid_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Add("Grid " + e.RoutedEvent.Name);
        }
        private void Grid_Click(object sender, RoutedEventArgs e)
        {
            listBox1.Items.Add("Grid " + e.RoutedEvent.Name);
        }
        private void btneventtest_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            listBox1.Items.Add("Button " + e.RoutedEvent.Name);
        }
        private void btneventtest_Click(object sender, RoutedEventArgs e)
        {
            listBox1.Items.Add("Button " + e.RoutedEvent.Name);
        }
        private void Window_Click(object sender, RoutedEventArgs e)
        {
            listBox1.Items.Add("Window " + e.RoutedEvent.Name);
        }
    }
}
