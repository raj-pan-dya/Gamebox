﻿/*******************************************************************************************************
 * Author        : Rudrendra Uday Ambike
 * Desc          : Medicare corporation is company involed in the business of maintaing details of doctors and distributin it to customer via post in liu of payment. 
 *                 This information helps patients to find appropriate doctor based on their ailment.
 * File          : Person.cs
 * Version       : 1.0
 * Creation Date : 5 December 2018
 * ****************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    public class Person
    {
        public int _id;
        public string _name;
        public int _age;
        public string _dob;

        //Properties of Person Class
        public int Id {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }


        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        public string DOB
        {
            get
            {
                return _dob;
            }
            set
            {
                _dob = value;
            }
        }

        //Use of Virtual Keyword
        public virtual void PrintDetails()
        {
            Console.WriteLine("Enter ID:");
            Id = Convert.ToInt32(Console.ReadLine()) ;

            Console.WriteLine("Enter Name:");
            Name = Console.ReadLine();


            Console.WriteLine("Enter Age:");
            Age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter DOB:");
            DOB= Console.ReadLine();
            Console.WriteLine("-----------------------");

            Console.WriteLine("ID : "+Id);
            Console.WriteLine("Name "+Name);
            Console.WriteLine("Age: "+Age);
            Console.WriteLine("DOB: "+DOB);

            
        }


    }
}
