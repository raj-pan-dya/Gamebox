﻿/*******************************************************************************************************
 * Author        : Rudrendra Uday Ambike
 * Desc          : Medicare corporation is company involed in the business of maintaing details of doctors and distributin it to customer via post in liu of payment. 
 *                 This information helps patients to find appropriate doctor based on their ailment.
 * File          : Customer.cs
 * Version       : 1.0
 * Creation Date : 5 December 2018
 * ****************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    //Inherited from Person class
    public class Customer:Person
    {
        public string _address;
        public string _city;

        public string Address
        {
            get{
                return _address;
            }
            set{
                _address = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }
        //override is used here

        public override void PrintDetails()
        {
            Console.WriteLine("Enter Address:");
            Address = Console.ReadLine();

            Console.WriteLine("Address: "+Address);

            Console.WriteLine("Enter City:");
            City = Console.ReadLine();
            Console.WriteLine("***********************************");

            Console.WriteLine("Address is: "+Address);
            Console.WriteLine("City is: "+City);
        }
    }
}
