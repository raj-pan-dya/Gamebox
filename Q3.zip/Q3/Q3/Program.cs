﻿/*******************************************************************************************************
 * Author        : Rudrendra Uday Ambike
 * Desc          : Medicare corporation is company involed in the business of maintaing details of doctors and distributin it to customer via post in liu of payment. 
 *                 This information helps patients to find appropriate doctor based on their ailment.
 * File          : Program.cs
 * Version       : 1.0
 * Creation Date : 5 December 2018
 * ****************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating object of Customer class
            Customer objCustomer = new Customer();

            
            objCustomer.PrintDetails();//accessing with object of customer class

            Person objPerson = new Person();
            objPerson.PrintDetails();//accessing with object of person class
        }
    }
}
