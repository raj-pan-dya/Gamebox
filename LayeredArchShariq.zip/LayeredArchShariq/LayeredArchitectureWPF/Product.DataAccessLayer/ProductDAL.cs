﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using Product.Entities;
using Product.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace Product.DataAccessLayer
{
    public class ProductDAL
    {
        SqlConnection cn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool InsertDAL(Products product)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Shariq.USP_ProductInsert", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isInserted;
        }

        public bool UpdateDAL(Products product)
        {
            bool isUpdated = false;
            try
            {
                cmd = new SqlCommand("Shariq.USP_ProductUpdate", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isUpdated;
        }

        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("Shariq.USP_ProductDelete", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

            return isDeleted;

        }

        public IEnumerable<Products> SelectDAL()
        {
            List<Products> products = new List<Products>();
            try
            {
                cmd = new SqlCommand("select * from Shariq.Product", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Products p = new Products();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();

            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return products;

        }
    }
}
