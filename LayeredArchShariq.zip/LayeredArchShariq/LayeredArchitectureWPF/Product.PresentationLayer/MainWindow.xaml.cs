﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Product.Entities;
using Product.Exceptions;
using Product.BusinessLayer;

namespace Product.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductBL prodBL = new ProductBL();

        Products prod = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void DisplayOnGrid()
        {
            try
            {
                IEnumerable<Products> prods = prodBL.SelectBL();
                dataGridProd.ItemsSource = prods;
                comboName.ItemsSource = prods;
                comboName.DisplayMemberPath = "ProdName";

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private bool IsValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (comboName.Text == null | comboName.Text == string.Empty | comboName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (txtDate.Text.ToString() == null | txtDate.Text == string.Empty | txtDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Product_Exception(sb.ToString());
            }

            return isValid;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayOnGrid();
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            prod = (Products)comboName.SelectedItem;
        }

        private void Btn_insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValid())
                {
                    Products pro = new Products
                    {
                        ProdName = comboName.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(txtDate.Text)

                    };

                    prodBL.InsertBL(pro);
                    MessageBox.Show("Inserted Succesfully");
                    DisplayOnGrid();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void Btn_update_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (IsValid())
                {
                    prod.ProdName = comboName.Text;
                    prod.Price = Convert.ToDecimal(txtPrice.Text);
                    prod.ExpDate = Convert.ToDateTime(txtDate.Text);
                    prodBL.UpdateBL(prod);
                    MessageBox.Show("Update Succesfully");
                    DisplayOnGrid();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void Btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValid())
                {
                    prod = (Products)comboName.SelectedItem;

                    prodBL.DeleteBL(prod.Id);
                    MessageBox.Show("Deleted Succesfully");
                    DisplayOnGrid();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }
    }
}
