﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product.Entities;
using Product.Exceptions;
using Product.DataAccessLayer;

namespace Product.BusinessLayer
{
    public class ProductBL
    {
        private static bool IsInputValid(Products product)
        {
            StringBuilder sb = new StringBuilder();
            bool validProduct = true;
            if (product.ProdName.Length < 2)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Product Name Invalid");

            }
            if (product.Price < 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Price Value");

            }

            if (product.ExpDate.Date.ToString() == (DateTime.Now.Date).ToString())
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Expired Product");
            }
            if (validProduct == false)
                throw new Product_Exception(sb.ToString());

            return validProduct;
        }

        public bool InsertBL(Products product)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL prodDAL = new ProductDAL();
                    isInserted = prodDAL.InsertDAL(product);

                }

            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isInserted;
        }

        public bool UpdateBL(Products product)
        {
            bool isUpdated = false;
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL prodDAL = new ProductDAL();
                    isUpdated = prodDAL.UpdateDAL(product);

                }

            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isUpdated;
        }

        public bool DeleteBL(int id)
        {
            bool isDeleted = false;

            try
            {
                ProductDAL prodDAL = new ProductDAL();
                isDeleted = prodDAL.DeleteDAL(id);

            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isDeleted;
        }

        public IEnumerable<Products> SelectBL()
        {

            IEnumerable<Products> products = null;
            try
            {

                ProductDAL prodDL = new ProductDAL();
                products = prodDL.SelectDAL();

            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }

            return products;
        }
    }
}
