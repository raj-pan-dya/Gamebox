﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ProductDetails
{
   public class ProductOps
    {
        Product objProd = new Product();
        public ArrayList prodList = new ArrayList();
        public void AddProduct()
        {
            

            Console.WriteLine("Enter the Product Details.");

            Console.WriteLine("Enter the Product NO:");
            objProd.ProductNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Name:");
            objProd.ProductName = Console.ReadLine();

            Console.WriteLine("Enter the Product Rate:");
            objProd.Rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Stock:");
            objProd.Stock = Convert.ToInt32(Console.ReadLine());

            prodList.Add(objProd);

            Console.WriteLine("success");

        }

        public void SearchProduct()
        {
            Console.WriteLine("Enter the ProductNo of the product which u want to search:");
            int prodNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(prodNo);


            //foreach (Product p in prodList)
            //{
            //    if (p.ProductNo== prodNo)
            //    {
            //        Console.WriteLine("ProductNO: " + p.ProductNo);
            //        Console.WriteLine("Product Name: " + p.ProductName);
            //        Console.WriteLine("Product Rate: " + p.Rate);
            //        Console.WriteLine("Product Stock: " + p.Stock);
            //        // objProd = prodList.Contains(prodNumber);
            //    }
            //    else
            //    {
            //        Console.WriteLine("Product Not Found");
            //    }
            //}
            //return objProd;
            //int myIndex = prodList.IndexOf(prodNo);
            //Console.WriteLine(myIndex);

        }
    }
}
