﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            
            char choice;
            do
            {

                Console.WriteLine("============================");
                Console.WriteLine("1.Add Product");
                Console.WriteLine("2.Delete Currently Searched Product");
                Console.WriteLine("3.Search Product");
                Console.WriteLine("4.Save the Product");
                Console.WriteLine("============================");


                ProductOps objProdOps = new ProductOps();

                Console.WriteLine("Enter your choice:");
                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {

                    case 1:
                        objProdOps.AddProduct();
                        break;
                    case 2:
                        break;
                    case 3:
                        objProdOps.SearchProduct();
                        break;
                    case 4:
                        break;
                    default:
                        Console.WriteLine("Enter Correct Choice");
                        break;


              

            }
             Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit.");
            choice = Convert.ToChar(Console.ReadLine());
        } while (choice == 'y');


        }
    }
}
