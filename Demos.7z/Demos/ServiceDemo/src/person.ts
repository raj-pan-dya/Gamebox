export interface IPerson{
    id:Number,
    name:String
}