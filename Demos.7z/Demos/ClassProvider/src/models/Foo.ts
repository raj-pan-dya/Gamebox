import { Inject } from '@angular/core';

export class Foo{
	constructor(){
		console.log("Foo");
	}
}