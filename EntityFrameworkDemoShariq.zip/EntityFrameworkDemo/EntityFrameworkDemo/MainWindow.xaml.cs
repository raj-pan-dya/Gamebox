﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFrameworkDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        int id;

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        public void PopulateUI()
        {
            List<Product> prods = dbContext.Products.ToList();
            var res = prods.Where(s => s.Price > 6);
            dgProd.ItemsSource = res;
            comboName.ItemsSource = res;
            comboName.DisplayMemberPath = "ProdName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            id = ((Product)comboName.SelectedItem).Id;
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Product prod = new Product();
            //write code to get data from controls and set to properties
            prod.ProdName = comboName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(txtDate.Text);
            dbContext.Products.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Product prod = dbContext.Products.Single(p => p.Id == id);
            prod.ProdName = comboName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(txtDate.Text);
            dbContext.SaveChanges();
            MessageBox.Show("Updated!");
            PopulateUI();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Product pro = (Product)comboName.SelectedItem;
            //Product prod = dbContext.Products.Single(s => s.Id == pro.Id);
            Product prod = (Product)comboName.SelectedItem;

            dbContext.Products.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
            PopulateUI();
        }


    }
}
