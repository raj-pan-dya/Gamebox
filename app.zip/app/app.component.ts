import { Component } from '@angular/core';
import { Person } from './Person';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'my-app',
  templateUrl: 'model-form.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // name: string = 'Monkey.D.Luffy';
  // url: string = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRveja-jF8OWdr0l6PrKLT-79604PdrfWuW5DRcYeHn_0YhHwVc0Q";
  // btn: string = 'One Piece';
  // username: string = '';
  // status = false;
  // month: string = "Feb";
  // cities: string[] = ['Mumbai', 'Pune', 'Bangalore', 'Kolkata'];
  // color: string = "red";
  // size: string = "12px";
  // colr: string = "red";

  // Show(): void {
  //   alert('One Piece');
  // }

  // isOn: boolean = false;
  // isDisabled: boolean = false;

  // toggle(newState: any): void {
  //   if (!this.isDisabled) {
  //     this.isOn = newState;
  //   }
  // }
  personForm: FormGroup;
  person: Person;
  constructor() {
    this.buildForm();
  }

  private buildForm() {

    this.personForm = new FormGroup({
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      Age: new FormControl(''),
      Address: new FormControl('')
    });
  }




  onSubmit(person: Person) {
    alert('Name: ' + person.firstName + " " + person.lastName + ' Age: ' + person.Age + ' Address: ' + person.Address);
  }

}
