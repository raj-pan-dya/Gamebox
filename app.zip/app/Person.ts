export interface Person {
    firstName: string;
    lastName: string;
    Age: number;
    Address: string;
    Date: string;
}