﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product.Entities;
using Product.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace Product.DataAccessLayer
{
    public class ProductDAL
    {
        SqlConnection conn = null;

        SqlCommand cmd = null;

        SqlDataReader dr = null;

        public ProductDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }

        public bool InsertDAL(Products product)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Sayali.USP_ProductInsert", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                conn.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return isInserted;
        }

        public bool UpdateDAL(Products product)
        {
            bool isUpdated = false;
            try
            {
                cmd = new SqlCommand("Sayali.USP_ProductUpdate", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                conn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return isUpdated;
        }

        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("Sayali.USP_ProductDelete", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

            return isDeleted;

        }

        public IEnumerable<Products> SelectDAL()
        {
            List<Products> products = new List<Products>();
            try
            {
                cmd = new SqlCommand("select * from Sayali.Product", conn);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Products p = new Products();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();

            }
            catch (Product_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return products;

        }
    }
}
