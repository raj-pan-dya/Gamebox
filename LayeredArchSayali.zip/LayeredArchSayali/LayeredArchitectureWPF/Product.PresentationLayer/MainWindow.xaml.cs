﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Product.Entities;
using Product.Exceptions;
using Product.BusinessLayer;

namespace Product.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        ProductBL productBL = new ProductBL();

        Products prod = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void PopulateData()

        {
            try
            {
                IEnumerable<Products> prods = productBL.SelectBL();
                dgProducts.ItemsSource = prods;
                cmbProducts.ItemsSource = prods;
                cmbProducts.DisplayMemberPath = "ProdName";

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private bool IsValidBL()
        {
            bool IsValidBL = true;
            StringBuilder sb = new StringBuilder();

            if (cmbProducts.Text == null | cmbProducts.Text == string.Empty | cmbProducts.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                IsValidBL = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                IsValidBL = false;
            }
            if (dpDate.Text.ToString() == null | dpDate.Text == string.Empty | dpDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                IsValidBL = false;
            }

            if (!IsValidBL)
            {
                throw new Product_Exception(sb.ToString());
            }

            return IsValidBL;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            prod = (Products)cmbProducts.SelectedItem;
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)

        {
            try
            {
                if (IsValidBL())
                {
                    prod = (Products)cmbProducts.SelectedItem;

                    productBL.DeleteBL(prod.Id);
                    MessageBox.Show("Deleted Succesfully");
                    PopulateData();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)

        {
            try
            {

                if (IsValidBL())
                {
                    prod.ProdName = cmbProducts.Text;
                    prod.Price = Convert.ToDecimal(txtPrice.Text);
                    prod.ExpDate = Convert.ToDateTime(dpDate.Text);
                    productBL.UpdateBL(prod);
                    MessageBox.Show("Update Succesfully");
                    PopulateData();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)

        {
            try
            {
                if (IsValidBL())
                {
                    Products pro = new Products
                    {
                        ProdName = cmbProducts.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(dpDate.Text)

                    };

                    productBL.InsertBL(pro);
                    MessageBox.Show("Inserted Succesfully");
                    PopulateData();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
